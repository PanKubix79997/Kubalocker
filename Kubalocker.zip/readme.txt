# WARNING: This is a real ransomware

**DO NOT run this program on any physical or important hardware.**

This software is designed for educational and testing purposes only. Running it on your actual machine may cause irreversible data loss or system damage.

**Use only in a controlled virtual environment (VM) or sandbox.**

By proceeding to use this software, you acknowledge that you do so at your own risk. The author is not responsible for any damage or data loss caused.

---

**Important:**  
- Do NOT open on physical machines.  
- Use only in isolated environments.  
- Backup all important data before testing.
